package com.example.administrador.curso3_tarea5.presentador;

/**
 * Created by administrador on 27/05/17.
 */

public interface IHomeFragmentPresenter {

    public void obtenerMascotasBaseDatos();

    public void mostrarMascotasRV();
}
